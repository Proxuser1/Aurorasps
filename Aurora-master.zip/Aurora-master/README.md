# Aurora Proxy
A fast and powerful proxy made in go. This project is currently in beta. Anything you see here is subject to change.

# Contributing Information
Please send your changes through a pull request. Make sure you run gofmt before you commit your changes if you modify or create a go file.